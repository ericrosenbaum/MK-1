MK-1
====

A sampling synth for Makey Makey invention kit, inspired by the classic Casio SK-1 sampling keyboard. 

Built with p5.js

Try it: http://ericrosenbaum.github.io/MK-1/
